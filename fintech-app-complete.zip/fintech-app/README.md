# FinVest – Financial Product Discovery Platform

**FAST National University | BS FinTech | Web Programming Assignment**  
Course Instructor: Arsalan Khan

---

## Project Overview

FinVest is a Dynamic Financial Product Discovery Platform built with **React**. It fetches real product data from the Fake Store API, transforms it into financial instruments, and provides:

- Personalized product recommendations based on user risk profile
- Portfolio management with weighted return calculations
- Multi-criteria product filtering (risk, return, liquidity, horizon, budget)
- Return projection calculator using compound interest

---

## Features Implemented

| Feature | Status |
|---|---|
| Home Page with featured products & category navigation | ✅ |
| Product Listing with 6 filter types | ✅ |
| Product Detail with dynamic routing (`/product/:id`) | ✅ |
| Return Projection Calculator | ✅ |
| Product Comparison (side-by-side) | ✅ |
| User Financial Profile Form (5 fields, validated) | ✅ |
| Recommendation Engine (risk/horizon/liquidity/budget filters) | ✅ |
| Portfolio Management (add/remove/edit amounts) | ✅ |
| Weighted Return & Risk Distribution calculations | ✅ |
| Diversification Score | ✅ |
| Context API (PortfolioContext + UserProfileContext) | ✅ |
| localStorage persistence | ✅ |
| Responsive design | ✅ |
| API Integration (Fake Store API) | ✅ |
| Data Transformation Layer | ✅ |
| React Router with 7 routes including 404 | ✅ |
| Animations (hover, transitions, page enter) | ✅ |
| Search with sorting | ✅ |

---

## Installation & Setup

### Prerequisites
- **Node.js** v16 or higher (download from [nodejs.org](https://nodejs.org))
- **npm** (comes with Node.js)

### Steps

```bash
# 1. Extract the zip and open terminal in the project folder
cd fintech-discovery-platform

# 2. Install dependencies
npm install

# 3. Start development server
npm start

# 4. Open in browser
# http://localhost:3000
```

---

## Component Hierarchy

```
App
├── BrowserRouter
│   ├── PortfolioProvider (Context)
│   │   └── UserProfileProvider (Context)
│   │       ├── Navbar
│   │       └── Routes
│   │           ├── Home
│   │           │   └── ProductCard (×6)
│   │           ├── ProductListing
│   │           │   ├── FilterPanel
│   │           │   └── ProductCard (×n)
│   │           ├── ProductDetail
│   │           │   ├── RiskBadge
│   │           │   └── ReturnDisplay
│   │           ├── UserProfile
│   │           │   └── ProfileForm
│   │           ├── Portfolio
│   │           │   ├── PortfolioItem (×n)
│   │           │   └── PortfolioSummary
│   │           └── Recommendations
│   │               └── RecommendationList
│   │                   └── ProductCard (×n)
```

---

## Financial Logic Explanation

### Data Transformation
Raw Fake Store API data is mapped to financial products:
- `electronics` → `investment` (medium risk, 7–12% return)
- `jewelery` → `savings` (low risk, 3–7% return)
- `men's clothing` → `insurance` (low risk, locked liquidity)
- `women's clothing` → `crypto` (high risk, 12–27% return)

### Recommendation Algorithm
1. Filter by risk tolerance (conservative = low only, moderate = low+medium, aggressive = all)
2. Filter by investment horizon (short ⊆ medium ⊆ long)
3. Filter by liquidity (easy ⊆ moderate ⊆ locked)
4. Filter by budget (minInvestment ≤ monthlyCapacity)
5. Sort by relevance to user goal

### Portfolio Calculations
- **Total Invested** = Σ allocatedAmount
- **Weighted Return** = Σ (allocatedAmount / total) × expectedReturn
- **Risk Distribution** = % of total in each risk category
- **Diversification Score** = f(unique categories, unique risks, item count)

---

## API Used

**Fake Store API** – https://fakestoreapi.com/products  
Free, no key required. Returns 20 products which are transformed into financial instruments.

---

## Folder Structure

```
src/
├── components/       # Reusable UI components
│   ├── Navbar.js
│   ├── ProductCard.js
│   ├── FilterPanel.js
│   ├── RiskBadge.js
│   ├── ReturnDisplay.js
│   ├── PortfolioSummary.js
│   ├── PortfolioItem.js
│   ├── ProfileForm.js
│   └── RecommendationList.js
├── contexts/         # Global state management
│   ├── PortfolioContext.js
│   └── UserProfileContext.js
├── pages/            # Route-level pages
│   ├── Home.js
│   ├── ProductListing.js
│   ├── ProductDetail.js
│   ├── UserProfile.js
│   ├── Portfolio.js
│   ├── Recommendations.js
│   └── NotFound.js
├── utils/            # Business logic utilities
│   ├── transformData.js
│   └── recommendations.js
├── styles/
│   └── global.css
├── App.js
└── index.js
```
