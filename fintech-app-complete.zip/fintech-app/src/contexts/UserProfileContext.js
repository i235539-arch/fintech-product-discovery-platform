import React, { createContext, useContext, useState, useEffect } from "react";

const UserProfileContext = createContext(null);

const DEFAULT_PROFILE = {
  riskTolerance: "",
  investmentHorizon: "",
  monthlyCapacity: "",
  liquidityPreference: "",
  investmentGoal: "",
};

export function UserProfileProvider({ children }) {
  const [profile, setProfile] = useState(() => {
    try {
      const saved = localStorage.getItem("finvest_profile");
      return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  });

  const [profileSaved, setProfileSaved] = useState(false);

  useEffect(() => {
    localStorage.setItem("finvest_profile", JSON.stringify(profile));
  }, [profile]);

  function updateProfile(updates) {
    setProfile((prev) => ({ ...prev, ...updates }));
  }

  function saveProfile(data) {
    setProfile(data);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  }

  function resetProfile() {
    setProfile(DEFAULT_PROFILE);
    localStorage.removeItem("finvest_profile");
  }

  const hasProfile = Boolean(profile.riskTolerance && profile.investmentHorizon);

  return (
    <UserProfileContext.Provider
      value={{ profile, updateProfile, saveProfile, resetProfile, hasProfile, profileSaved }}
    >
      {children}
    </UserProfileContext.Provider>
  );
}

export function useUserProfile() {
  const ctx = useContext(UserProfileContext);
  if (!ctx) throw new Error("useUserProfile must be used inside UserProfileProvider");
  return ctx;
}
