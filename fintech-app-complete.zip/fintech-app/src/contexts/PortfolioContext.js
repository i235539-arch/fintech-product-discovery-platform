import React, { createContext, useContext, useState, useEffect } from "react";

const PortfolioContext = createContext(null);

export function PortfolioProvider({ children }) {
  const [portfolio, setPortfolio] = useState(() => {
    try {
      const saved = localStorage.getItem("finvest_portfolio");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Persist to localStorage
  useEffect(() => {
    localStorage.setItem("finvest_portfolio", JSON.stringify(portfolio));
  }, [portfolio]);

  /**
   * Add a product to portfolio with a default allocated amount
   */
  function addToPortfolio(product) {
    setPortfolio((prev) => {
      if (prev.find((item) => item.id === product.id)) return prev;
      return [
        ...prev,
        {
          ...product,
          allocatedAmount: product.minInvestment,
          addedAt: new Date().toISOString(),
        },
      ];
    });
  }

  /**
   * Remove product from portfolio by id
   */
  function removeFromPortfolio(id) {
    setPortfolio((prev) => prev.filter((item) => item.id !== id));
  }

  /**
   * Update the allocated amount for a portfolio item
   */
  function updateAmount(id, amount) {
    setPortfolio((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, allocatedAmount: Math.max(item.minInvestment, parseFloat(amount) || item.minInvestment) }
          : item
      )
    );
  }

  /**
   * Check if a product is in the portfolio
   */
  function isInPortfolio(id) {
    return portfolio.some((item) => item.id === id);
  }

  /**
   * Total invested across all portfolio items
   */
  const totalInvested = portfolio.reduce((sum, item) => sum + item.allocatedAmount, 0);

  /**
   * Weighted expected return = Σ (weight_i × return_i)
   * where weight_i = allocatedAmount_i / totalInvested
   */
  const weightedReturn =
    totalInvested > 0
      ? portfolio.reduce(
          (sum, item) => sum + (item.allocatedAmount / totalInvested) * item.expectedReturn,
          0
        )
      : 0;

  /**
   * Risk distribution: percentage of portfolio in each risk category
   */
  const riskDistribution = portfolio.reduce(
    (acc, item) => {
      const pct = totalInvested > 0 ? (item.allocatedAmount / totalInvested) * 100 : 0;
      acc[item.riskLevel] = (acc[item.riskLevel] || 0) + pct;
      return acc;
    },
    { low: 0, medium: 0, high: 0 }
  );

  /**
   * Category distribution
   */
  const categoryDistribution = portfolio.reduce((acc, item) => {
    const pct = totalInvested > 0 ? (item.allocatedAmount / totalInvested) * 100 : 0;
    acc[item.category] = (acc[item.category] || 0) + pct;
    return acc;
  }, {});

  /**
   * Diversification score (0-100)
   * Based on: number of categories, risk spread, number of items
   */
  const diversificationScore = (() => {
    if (portfolio.length === 0) return 0;
    const uniqueCategories = new Set(portfolio.map((p) => p.category)).size;
    const uniqueRisks = new Set(portfolio.map((p) => p.riskLevel)).size;
    const itemCount = Math.min(portfolio.length, 10);
    return Math.min(
      100,
      Math.round((uniqueCategories / 4) * 40 + (uniqueRisks / 3) * 35 + (itemCount / 10) * 25)
    );
  })();

  /**
   * Warning if too concentrated in high-risk
   */
  const highRiskWarning = riskDistribution.high > 60;

  return (
    <PortfolioContext.Provider
      value={{
        portfolio,
        addToPortfolio,
        removeFromPortfolio,
        updateAmount,
        isInPortfolio,
        totalInvested,
        weightedReturn,
        riskDistribution,
        categoryDistribution,
        diversificationScore,
        highRiskWarning,
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
}

export function usePortfolio() {
  const ctx = useContext(PortfolioContext);
  if (!ctx) throw new Error("usePortfolio must be used inside PortfolioProvider");
  return ctx;
}
