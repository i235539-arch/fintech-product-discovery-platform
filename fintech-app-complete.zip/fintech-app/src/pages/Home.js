import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import ProductCard from "../components/ProductCard";
import { usePortfolio } from "../contexts/PortfolioContext";
import { useUserProfile } from "../contexts/UserProfileContext";

export default function Home({ products, loading }) {
  const { addToPortfolio, isInPortfolio } = usePortfolio();
  const { hasProfile } = useUserProfile();
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState(null);

  const featured = products.slice(0, 6);

  const categories = [
    { key: "savings", label: "Savings", icon: "🏦", desc: "Low risk, stable returns", color: "var(--accent)" },
    { key: "investment", label: "Investment", icon: "📈", desc: "Growth-focused funds", color: "var(--gold)" },
    { key: "insurance", label: "Insurance", icon: "🛡️", desc: "Risk protection plans", color: "#ce93d8" },
    { key: "crypto", label: "Crypto", icon: "₿", desc: "Digital asset exposure", color: "#ff8a80" },
  ];

  const stats = [
    { value: products.length, label: "Financial Products" },
    { value: "4", label: "Asset Classes" },
    { value: "100%", label: "API-Driven Data" },
    { value: "Free", label: "To Explore" },
  ];

  function handleCategoryClick(cat) {
    setActiveCategory(cat.key);
    navigate(`/products?category=${cat.key}`);
  }

  return (
    <div className="page-wrapper page-enter">
      {/* Hero */}
      <section
        style={{
          minHeight: "88vh",
          display: "flex",
          alignItems: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Background elements */}
        <div
          style={{
            position: "absolute",
            top: "10%",
            right: "-10%",
            width: 600,
            height: 600,
            background: "radial-gradient(circle, rgba(0,212,255,0.06) 0%, transparent 70%)",
            borderRadius: "50%",
            pointerEvents: "none",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: "5%",
            left: "-5%",
            width: 400,
            height: 400,
            background: "radial-gradient(circle, rgba(245,166,35,0.05) 0%, transparent 70%)",
            borderRadius: "50%",
            pointerEvents: "none",
          }}
        />

        <div className="container" style={{ padding: "80px 24px" }}>
          <div style={{ maxWidth: 700 }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                background: "var(--accent-dim)",
                border: "1px solid var(--border-strong)",
                borderRadius: 20,
                padding: "6px 14px",
                fontSize: 12,
                color: "var(--accent)",
                fontWeight: 600,
                marginBottom: 28,
                textTransform: "uppercase",
                letterSpacing: "0.5px",
              }}
            >
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent)", display: "inline-block" }} />
              FAST FinTech · Web Programming Assignment
            </div>

            <h1
              style={{
                fontSize: "clamp(36px, 6vw, 68px)",
                fontWeight: 800,
                lineHeight: 1.1,
                letterSpacing: "-1.5px",
                marginBottom: 24,
                color: "var(--text-primary)",
              }}
            >
              Discover Financial
              <br />
              <span
                style={{
                  color: "var(--accent)",
                  position: "relative",
                }}
              >
                Products
              </span>{" "}
              Built
              <br />
              for Pakistan.
            </h1>

            <p
              style={{
                fontSize: 18,
                color: "var(--text-secondary)",
                lineHeight: 1.7,
                maxWidth: 540,
                marginBottom: 36,
              }}
            >
              Explore savings, investments, insurance, and crypto with personalized 
              recommendations based on your financial profile and risk tolerance.
            </p>

            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <Link to="/profile" className="btn btn-primary" style={{ fontSize: 15, padding: "14px 28px" }}>
                Build My Profile →
              </Link>
              <Link to="/products" className="btn btn-outline" style={{ fontSize: 15, padding: "14px 28px" }}>
                Browse Products
              </Link>
            </div>

            {!hasProfile && (
              <div style={{ marginTop: 20, fontSize: 13, color: "var(--text-muted)" }}>
                💡 Create a profile to get personalized recommendations
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section style={{ background: "var(--bg-secondary)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
        <div className="container" style={{ padding: "32px 24px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
            {stats.map((s, i) => (
              <div key={i} style={{ textAlign: "center" }}>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: 28, fontWeight: 700, color: "var(--accent)" }}>
                  {loading && typeof s.value === "number" ? "..." : s.value}
                </div>
                <div style={{ fontSize: 12, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginTop: 4 }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Category Cards */}
      <section style={{ padding: "80px 0" }}>
        <div className="container">
          <h2 className="section-title">Browse by Asset Class</h2>
          <p className="section-subtitle">Click a category to explore specific financial products</p>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
            {categories.map((cat) => (
              <div
                key={cat.key}
                onClick={() => handleCategoryClick(cat)}
                style={{
                  background: "var(--bg-card)",
                  border: `1px solid var(--border)`,
                  borderRadius: "var(--radius-lg)",
                  padding: "28px 20px",
                  cursor: "pointer",
                  textAlign: "center",
                  transition: "all 0.3s ease",
                  position: "relative",
                  overflow: "hidden",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = cat.color + "60";
                  e.currentTarget.style.transform = "translateY(-6px)";
                  e.currentTarget.style.boxShadow = `0 12px 40px rgba(0,0,0,0.4)`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = "var(--border)";
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                <div style={{ fontSize: 36, marginBottom: 14 }}>{cat.icon}</div>
                <div style={{ fontWeight: 700, fontSize: 16, color: "var(--text-primary)", marginBottom: 6 }}>
                  {cat.label}
                </div>
                <div style={{ fontSize: 13, color: "var(--text-secondary)" }}>{cat.desc}</div>
                <div
                  style={{
                    marginTop: 14,
                    fontSize: 12,
                    color: cat.color,
                    fontWeight: 600,
                    textTransform: "uppercase",
                    letterSpacing: "0.5px",
                  }}
                >
                  {loading ? "..." : `${products.filter((p) => p.category === cat.key).length} products →`}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section style={{ padding: "0 0 80px" }}>
        <div className="container">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 32 }}>
            <div>
              <h2 className="section-title">Featured Products</h2>
              <p style={{ color: "var(--text-secondary)", fontSize: 15 }}>Top picks across all categories</p>
            </div>
            <Link to="/products" className="btn btn-outline" style={{ fontSize: 13 }}>
              View All →
            </Link>
          </div>

          {loading ? (
            <div className="loading-spinner">
              <div className="spinner" />
              <span style={{ color: "var(--text-secondary)", fontSize: 14 }}>Fetching financial products...</span>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 20 }}>
              {featured.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToPortfolio={addToPortfolio}
                  isInPortfolio={isInPortfolio(product.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section
        style={{
          background: "var(--bg-secondary)",
          borderTop: "1px solid var(--border)",
          padding: "80px 0",
          textAlign: "center",
        }}
      >
        <div className="container">
          <div
            style={{
              maxWidth: 560,
              margin: "0 auto",
            }}
          >
            <div style={{ fontSize: 40, marginBottom: 20 }}>🎯</div>
            <h2 style={{ fontSize: 32, fontWeight: 800, marginBottom: 16, color: "var(--text-primary)" }}>
              Get Personalized Recommendations
            </h2>
            <p style={{ color: "var(--text-secondary)", fontSize: 16, lineHeight: 1.7, marginBottom: 32 }}>
              Tell us your risk tolerance, investment horizon, and goals. Our algorithm
              will find the products that are the right fit for you.
            </p>
            <Link to="/profile" className="btn btn-primary" style={{ fontSize: 15, padding: "14px 32px" }}>
              Create My Financial Profile →
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
