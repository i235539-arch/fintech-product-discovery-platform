import React, { useState, useMemo } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import RiskBadge from "../components/RiskBadge";
import ReturnDisplay from "../components/ReturnDisplay";
import { usePortfolio } from "../contexts/PortfolioContext";
import { formatCurrency, calcProjectedReturn, riskColor } from "../utils/transformData";

export default function ProductDetail({ products }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToPortfolio, isInPortfolio } = usePortfolio();
  const [calcAmount, setCalcAmount] = useState("");
  const [compareId, setCompareId] = useState("");
  const [added, setAdded] = useState(false);

  const product = products.find((p) => String(p.id) === String(id));
  const compareProduct = products.find((p) => String(p.id) === String(compareId));

  if (!product) {
    return (
      <div className="page-wrapper page-enter">
        <div className="container" style={{ padding: "80px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 60, marginBottom: 20 }}>404</div>
          <h2 style={{ color: "var(--text-primary)", marginBottom: 12 }}>Product Not Found</h2>
          <Link to="/products" className="btn btn-primary">← Back to Products</Link>
        </div>
      </div>
    );
  }

  const inPortfolio = isInPortfolio(product.id);
  const projections = [1, 3, 5, 10].map((yr) => ({
    years: yr,
    value: calcProjectedReturn(parseFloat(calcAmount) || product.minInvestment, product.expectedReturn, yr),
  }));

  const riskPct = { low: 25, medium: 55, high: 90 }[product.riskLevel] || 50;

  const suitabilityText = {
    low: "Conservative investors seeking capital preservation. Ideal for emergency funds and short-term goals. Suitable for those near retirement or with low risk tolerance.",
    medium: "Balanced investors comfortable with moderate fluctuations. Good for medium-term wealth building and diversification goals.",
    high: "Aggressive investors with high risk tolerance and long time horizons. Not suitable for funds needed within 2 years.",
  }[product.riskLevel];

  function handleAdd() {
    addToPortfolio(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  const liquidityInfo = { easy: "Funds can be withdrawn at any time with minimal or no penalty.", moderate: "Some waiting period (weeks to months) may apply before withdrawal.", locked: "Funds are committed for the full investment term. Early withdrawal may incur heavy penalties." };
  const horizonInfo = { short: "Best suited for 1–2 year plans.", medium: "Optimal for 3–5 year investment plans.", long: "Designed for 5+ year commitments, allowing compound growth." };

  return (
    <div className="page-wrapper page-enter">
      <div className="container" style={{ padding: "40px 24px" }}>
        {/* Back */}
        <button onClick={() => navigate(-1)} className="btn btn-ghost" style={{ marginBottom: 28, fontSize: 13 }}>
          ← Back
        </button>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 32, alignItems: "start" }}>
          {/* LEFT COLUMN */}
          <div>
            {/* Header */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 28, marginBottom: 20 }}>
              <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
                <div style={{ width: 80, height: 80, background: "var(--surface)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <img src={product.image} alt={product.name} style={{ width: "70%", height: "70%", objectFit: "contain" }} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                    <span className={`badge badge-${product.category}`}>{product.category}</span>
                    <RiskBadge riskLevel={product.riskLevel} />
                  </div>
                  <h1 style={{ fontSize: 22, fontWeight: 800, color: "var(--text-primary)", lineHeight: 1.3, marginBottom: 10 }}>{product.name}</h1>
                  <p style={{ color: "var(--text-secondary)", fontSize: 14, lineHeight: 1.7 }}>{product.description}</p>
                </div>
              </div>
            </div>

            {/* Key Metrics Grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 20 }}>
              {[
                { label: "Expected Return", value: <ReturnDisplay value={product.expectedReturn} showTrend size="lg" />, sub: "Per annum" },
                { label: "Min. Investment", value: <span style={{ fontFamily: "var(--font-mono)", fontSize: 20, color: "var(--gold)", fontWeight: 700 }}>{formatCurrency(product.minInvestment)}</span>, sub: "Minimum to start" },
                { label: "Liquidity", value: <span style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)" }}>{product.liquidity}</span>, sub: liquidityInfo[product.liquidity].split(".")[0] },
              ].map((m, i) => (
                <div key={i} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius)", padding: 16 }}>
                  <div style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>{m.label}</div>
                  {m.value}
                  <div style={{ fontSize: 11, color: "var(--text-secondary)", marginTop: 6 }}>{m.sub}</div>
                </div>
              ))}
            </div>

            {/* Risk Visualization */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 24, marginBottom: 20 }}>
              <h3 style={{ fontWeight: 700, fontSize: 15, marginBottom: 16, color: "var(--text-primary)" }}>Risk Level Gauge</h3>
              <div style={{ position: "relative", height: 10, background: "linear-gradient(90deg, #00e676, #ffc107, #ff5252)", borderRadius: 5, marginBottom: 10 }}>
                <div style={{ position: "absolute", top: "50%", left: `${riskPct}%`, transform: "translate(-50%, -50%)", width: 20, height: 20, background: riskColor(product.riskLevel), borderRadius: "50%", border: "3px solid var(--bg-card)", boxShadow: "0 0 10px " + riskColor(product.riskLevel) }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--text-muted)" }}>
                <span>Low</span><span>Medium</span><span>High</span>
              </div>
            </div>

            {/* Attribute Explanations */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 24, marginBottom: 20 }}>
              <h3 style={{ fontWeight: 700, fontSize: 15, marginBottom: 16, color: "var(--text-primary)" }}>What Each Metric Means</h3>
              {[
                { term: "Expected Return", def: `${product.expectedReturn}% per year. This is the projected annual gain. Not guaranteed but based on historical performance.` },
                { term: "Risk Level", def: `${product.riskLevel.charAt(0).toUpperCase() + product.riskLevel.slice(1)} — ${suitabilityText}` },
                { term: "Liquidity", def: liquidityInfo[product.liquidity] },
                { term: "Time Horizon", def: horizonInfo[product.timeHorizon] },
              ].map(({ term, def }) => (
                <div key={term} style={{ marginBottom: 14, paddingBottom: 14, borderBottom: "1px solid var(--border)" }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: "var(--accent)", marginBottom: 4 }}>{term}</div>
                  <div style={{ fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.6 }}>{def}</div>
                </div>
              ))}
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: "var(--accent)", marginBottom: 4 }}>Who Is This For?</div>
                <div style={{ fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.6 }}>{suitabilityText}</div>
              </div>
            </div>

            {/* Comparison */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 24 }}>
              <h3 style={{ fontWeight: 700, fontSize: 15, marginBottom: 16, color: "var(--text-primary)" }}>Compare With Another Product</h3>
              <select value={compareId} onChange={(e) => setCompareId(e.target.value)} className="form-select" style={{ marginBottom: 16 }}>
                <option value="">— Select a product to compare —</option>
                {products.filter((p) => p.id !== product.id).map((p) => (
                  <option key={p.id} value={p.id}>{p.name.slice(0, 50)}</option>
                ))}
              </select>
              {compareProduct && (
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  {[product, compareProduct].map((p, i) => (
                    <div key={p.id} style={{ background: "var(--surface)", borderRadius: "var(--radius)", padding: 14, border: i === 0 ? "1px solid var(--border-strong)" : "1px solid var(--border)" }}>
                      {i === 0 && <div style={{ fontSize: 10, color: "var(--accent)", fontWeight: 700, marginBottom: 6, textTransform: "uppercase" }}>Current</div>}
                      <div style={{ fontWeight: 700, fontSize: 13, color: "var(--text-primary)", marginBottom: 10 }}>{p.name.slice(0, 40)}</div>
                      {[
                        { label: "Return", value: `${p.expectedReturn}%`, color: riskColor(p.riskLevel) },
                        { label: "Risk", value: p.riskLevel },
                        { label: "Min. Invest", value: formatCurrency(p.minInvestment) },
                        { label: "Liquidity", value: p.liquidity },
                        { label: "Horizon", value: p.timeHorizon },
                      ].map(({ label, value, color }) => (
                        <div key={label} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 6 }}>
                          <span style={{ color: "var(--text-muted)" }}>{label}</span>
                          <span style={{ fontWeight: 700, color: color || "var(--text-primary)" }}>{value}</span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* RIGHT COLUMN */}
          <div>
            {/* Add to Portfolio */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-lg)", padding: 24, marginBottom: 20 }}>
              <button
                onClick={handleAdd}
                disabled={inPortfolio}
                className={`btn ${inPortfolio || added ? "btn-success" : "btn-primary"}`}
                style={{ width: "100%", justifyContent: "center", padding: "14px", fontSize: 15, marginBottom: 12 }}
              >
                {inPortfolio ? "✓ Already in Portfolio" : added ? "✓ Added to Portfolio!" : "+ Add to Portfolio"}
              </button>
              <div style={{ fontSize: 12, color: "var(--text-muted)", textAlign: "center" }}>
                Min. investment: {formatCurrency(product.minInvestment)}
              </div>
            </div>

            {/* Return Projection Calculator */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 24 }}>
              <h3 style={{ fontWeight: 700, fontSize: 15, marginBottom: 4, color: "var(--text-primary)" }}>Return Projection</h3>
              <p style={{ fontSize: 12, color: "var(--text-secondary)", marginBottom: 16 }}>Enter an amount to see projected returns (compound interest)</p>
              <div className="form-group" style={{ marginBottom: 16 }}>
                <label className="form-label">Investment Amount (PKR)</label>
                <input
                  type="number"
                  value={calcAmount}
                  onChange={(e) => setCalcAmount(e.target.value)}
                  className="form-input"
                  placeholder={`Min: ${formatCurrency(product.minInvestment)}`}
                  min={product.minInvestment}
                />
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {projections.map(({ years, value }) => (
                  <div key={years} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "var(--surface)", borderRadius: "var(--radius)", padding: "10px 14px" }}>
                    <span style={{ fontSize: 13, color: "var(--text-secondary)" }}>{years} year{years > 1 ? "s" : ""}</span>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontFamily: "var(--font-mono)", fontWeight: 700, fontSize: 14, color: "var(--accent)" }}>{formatCurrency(Math.round(value))}</div>
                      <div style={{ fontSize: 10, color: "var(--risk-low)" }}>+{formatCurrency(Math.round(value - (parseFloat(calcAmount) || product.minInvestment)))}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 12, fontSize: 11, color: "var(--text-muted)" }}>
                Formula: A = P × (1 + r)ⁿ · Based on {product.expectedReturn}% annual return
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
