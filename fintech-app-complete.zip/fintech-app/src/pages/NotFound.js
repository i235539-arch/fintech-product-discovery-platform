import React from "react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="page-wrapper page-enter" style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center", padding: "80px 24px" }}>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 100, fontWeight: 700, color: "var(--border)", lineHeight: 1 }}>404</div>
        <h2 style={{ fontWeight: 800, fontSize: 28, color: "var(--text-primary)", margin: "20px 0 12px" }}>Page Not Found</h2>
        <p style={{ color: "var(--text-secondary)", marginBottom: 32 }}>This route doesn't exist in our platform.</p>
        <Link to="/" className="btn btn-primary">← Back to Home</Link>
      </div>
    </div>
  );
}
