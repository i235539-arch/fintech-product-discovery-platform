import React from "react";
import { Link } from "react-router-dom";
import PortfolioItem from "../components/PortfolioItem";
import PortfolioSummary from "../components/PortfolioSummary";
import { usePortfolio } from "../contexts/PortfolioContext";

export default function Portfolio() {
  const { portfolio, removeFromPortfolio, updateAmount, totalInvested, weightedReturn, riskDistribution, categoryDistribution, diversificationScore, highRiskWarning } = usePortfolio();

  if (portfolio.length === 0) {
    return (
      <div className="page-wrapper page-enter">
        <div className="container" style={{ padding: "80px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 60, marginBottom: 20 }}>📂</div>
          <h2 style={{ fontWeight: 800, fontSize: 28, color: "var(--text-primary)", marginBottom: 12 }}>Your Portfolio is Empty</h2>
          <p style={{ color: "var(--text-secondary)", marginBottom: 28, fontSize: 16 }}>Start adding financial products to track your investments and see portfolio analytics.</p>
          <Link to="/products" className="btn btn-primary" style={{ fontSize: 15, padding: "12px 28px" }}>Browse Products →</Link>
        </div>
      </div>
    );
  }

  const catColors = { savings: "var(--accent)", investment: "var(--gold)", insurance: "#ce93d8", crypto: "#ff8a80" };

  return (
    <div className="page-wrapper page-enter">
      <div className="container" style={{ padding: "40px 24px" }}>
        <div style={{ marginBottom: 32 }}>
          <h1 className="section-title">My Portfolio</h1>
          <p className="section-subtitle">{portfolio.length} product{portfolio.length !== 1 ? "s" : ""} · Manage allocations and track performance</p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 28, alignItems: "start" }}>
          {/* Products List */}
          <div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {portfolio.map((item) => (
                <PortfolioItem key={item.id} item={item} onRemove={removeFromPortfolio} onUpdateAmount={updateAmount} />
              ))}
            </div>

            {/* Category breakdown */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 24, marginTop: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 16 }}>Category Breakdown</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {Object.entries(categoryDistribution).map(([cat, pct]) => (
                  <div key={cat}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                      <span style={{ fontSize: 13, color: "var(--text-secondary)", textTransform: "capitalize" }}>{cat}</span>
                      <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: catColors[cat] || "var(--accent)", fontWeight: 700 }}>{pct.toFixed(1)}%</span>
                    </div>
                    <div className="progress-bar-wrap">
                      <div className="progress-bar-fill" style={{ width: `${pct}%`, background: catColors[cat] || "var(--accent)", opacity: 0.7 }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Summary sidebar */}
          <div style={{ position: "sticky", top: "calc(var(--nav-height) + 20px)" }}>
            <PortfolioSummary
              portfolio={portfolio}
              totalInvested={totalInvested}
              weightedReturn={weightedReturn}
              riskDistribution={riskDistribution}
              diversificationScore={diversificationScore}
              highRiskWarning={highRiskWarning}
            />
            <div style={{ marginTop: 16 }}>
              <Link to="/products" className="btn btn-outline" style={{ width: "100%", justifyContent: "center" }}>+ Add More Products</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
