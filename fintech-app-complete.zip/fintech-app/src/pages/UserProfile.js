import React from "react";
import { useNavigate } from "react-router-dom";
import ProfileForm from "../components/ProfileForm";
import { useUserProfile } from "../contexts/UserProfileContext";
import { getRecommendations } from "../utils/recommendations";

export default function UserProfile({ products }) {
  const { profile, saveProfile, updateProfile, resetProfile, hasProfile, profileSaved } = useUserProfile();
  const navigate = useNavigate();

  const matchCount = hasProfile ? getRecommendations(products, profile).length : 0;

  const riskLabels = { conservative: "Conservative 🛡️", moderate: "Moderate ⚖️", aggressive: "Aggressive 🚀" };
  const horizonLabels = { short: "Short (1-2 yrs)", medium: "Medium (3-5 yrs)", long: "Long (5+ yrs)" };
  const liquidityLabels = { easy: "Easy Access", moderate: "Some Flexibility", locked: "Can Lock Funds" };
  const goalLabels = { wealth_building: "Wealth Building", retirement: "Retirement Planning", emergency_fund: "Emergency Fund", specific_purchase: "Specific Purchase" };

  function handleSubmit(data) {
    saveProfile(data);
    setTimeout(() => navigate("/recommendations"), 800);
  }

  return (
    <div className="page-wrapper page-enter">
      <div className="container" style={{ padding: "40px 24px", maxWidth: 960 }}>
        <div style={{ marginBottom: 36 }}>
          <h1 className="section-title">Financial Profile</h1>
          <p className="section-subtitle">Your answers power our recommendation engine — be honest for best results.</p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 32, alignItems: "start" }}>
          {/* Form */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 32 }}>
            <ProfileForm profile={profile} onSubmit={handleSubmit} onChange={updateProfile} />
          </div>

          {/* Sidebar: summary + preview */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16, position: "sticky", top: "calc(var(--nav-height) + 20px)" }}>
            {/* Success toast */}
            {profileSaved && (
              <div style={{ background: "var(--risk-low-dim)", border: "1px solid rgba(0,230,118,0.4)", borderRadius: "var(--radius)", padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, animation: "fadeInUp 0.3s ease" }}>
                <span style={{ fontSize: 18 }}>✅</span>
                <span style={{ color: "var(--risk-low)", fontWeight: 700, fontSize: 13 }}>Profile saved! Redirecting...</span>
              </div>
            )}

            {/* Current profile summary */}
            {hasProfile && (
              <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 20 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Current Profile</div>
                {[
                  { label: "Risk Tolerance", value: riskLabels[profile.riskTolerance] },
                  { label: "Horizon", value: horizonLabels[profile.investmentHorizon] },
                  { label: "Monthly Budget", value: profile.monthlyCapacity ? `PKR ${parseInt(profile.monthlyCapacity).toLocaleString()}` : "—" },
                  { label: "Liquidity", value: liquidityLabels[profile.liquidityPreference] },
                  { label: "Goal", value: goalLabels[profile.investmentGoal] },
                ].map(({ label, value }) => value && (
                  <div key={label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 8, paddingBottom: 8, borderBottom: "1px solid var(--border)" }}>
                    <span style={{ color: "var(--text-secondary)" }}>{label}</span>
                    <span style={{ fontWeight: 600, color: "var(--text-primary)" }}>{value || "—"}</span>
                  </div>
                ))}
                <button onClick={resetProfile} className="btn btn-danger" style={{ width: "100%", justifyContent: "center", marginTop: 8, fontSize: 12, padding: "8px" }}>Reset Profile</button>
              </div>
            )}

            {/* Match preview */}
            <div style={{ background: "var(--accent-dim)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-lg)", padding: 20, textAlign: "center" }}>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: 40, fontWeight: 700, color: "var(--accent)", marginBottom: 6 }}>
                {matchCount}
              </div>
              <div style={{ fontSize: 13, color: "var(--text-secondary)" }}>products match your current profile</div>
              {matchCount > 0 && (
                <button onClick={() => navigate("/recommendations")} className="btn btn-primary" style={{ marginTop: 16, width: "100%", justifyContent: "center", fontSize: 13 }}>
                  View Recommendations →
                </button>
              )}
            </div>

            {/* Info box */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)", padding: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", marginBottom: 12 }}>How it works</div>
              {["Your risk tolerance filters which products you see", "Your horizon limits time-commitment of products", "Your budget removes unaffordable products", "Your goal influences category prioritization"].map((tip, i) => (
                <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: 12, color: "var(--text-secondary)" }}>
                  <span style={{ color: "var(--accent)", flexShrink: 0, marginTop: 1 }}>→</span>
                  {tip}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
