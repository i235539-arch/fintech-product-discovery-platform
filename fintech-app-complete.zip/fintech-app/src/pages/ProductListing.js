import React, { useState, useEffect, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import ProductCard from "../components/ProductCard";
import FilterPanel from "../components/FilterPanel";
import { usePortfolio } from "../contexts/PortfolioContext";

const DEFAULT_FILTERS = {
  riskLevels: [],
  categories: [],
  liquidity: [],
  timeHorizon: [],
  minReturn: 0,
  maxReturn: 30,
  maxMinInvestment: "",
};

export default function ProductListing({ products, loading }) {
  const { addToPortfolio, isInPortfolio } = usePortfolio();
  const [searchParams] = useSearchParams();
  const [filters, setFilters] = useState(() => {
    const cat = searchParams.get("category");
    return cat ? { ...DEFAULT_FILTERS, categories: [cat] } : DEFAULT_FILTERS;
  });
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("return_desc");

  useEffect(() => {
    const cat = searchParams.get("category");
    if (cat) setFilters((f) => ({ ...f, categories: [cat] }));
  }, [searchParams]);

  const filtered = useMemo(() => {
    let result = [...products];
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter((p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
    }
    if (filters.riskLevels.length) result = result.filter((p) => filters.riskLevels.includes(p.riskLevel));
    if (filters.categories.length) result = result.filter((p) => filters.categories.includes(p.category));
    if (filters.liquidity.length) result = result.filter((p) => filters.liquidity.includes(p.liquidity));
    if (filters.timeHorizon.length) result = result.filter((p) => filters.timeHorizon.includes(p.timeHorizon));
    result = result.filter((p) => p.expectedReturn >= filters.minReturn && p.expectedReturn <= (filters.maxReturn || 100));
    if (filters.maxMinInvestment) result = result.filter((p) => p.minInvestment <= parseFloat(filters.maxMinInvestment));
    if (sort === "return_desc") result.sort((a, b) => b.expectedReturn - a.expectedReturn);
    else if (sort === "return_asc") result.sort((a, b) => a.expectedReturn - b.expectedReturn);
    else if (sort === "risk_asc") {
      const o = { low: 0, medium: 1, high: 2 };
      result.sort((a, b) => o[a.riskLevel] - o[b.riskLevel]);
    }
    else if (sort === "invest_asc") result.sort((a, b) => a.minInvestment - b.minInvestment);
    return result;
  }, [products, filters, search, sort]);

  return (
    <div className="page-wrapper page-enter">
      <div className="container" style={{ padding: "40px 24px" }}>
        <div style={{ marginBottom: 32 }}>
          <h1 className="section-title">All Financial Products</h1>
          <p className="section-subtitle">Browse and filter {products.length} products across 4 asset classes</p>
        </div>

        {/* Search + Sort bar */}
        <div style={{ display: "flex", gap: 12, marginBottom: 28, flexWrap: "wrap" }}>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="form-input"
            style={{ flex: 1, minWidth: 200 }}
            placeholder="🔍  Search products..."
          />
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="form-select" style={{ width: 200 }}>
            <option value="return_desc">Highest Return First</option>
            <option value="return_asc">Lowest Return First</option>
            <option value="risk_asc">Lowest Risk First</option>
            <option value="invest_asc">Lowest Min. Investment</option>
          </select>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 28, alignItems: "start" }}>
          {/* Filter Panel */}
          <FilterPanel filters={filters} onFilterChange={setFilters} productCount={filtered.length} />

          {/* Product Grid */}
          <div>
            {loading ? (
              <div className="loading-spinner"><div className="spinner" /><span style={{ color: "var(--text-secondary)" }}>Loading products...</span></div>
            ) : filtered.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 24px", background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: "var(--radius-lg)" }}>
                <div style={{ fontSize: 40, marginBottom: 16 }}>😕</div>
                <div style={{ fontWeight: 700, fontSize: 18, color: "var(--text-primary)", marginBottom: 8 }}>No products match your filters</div>
                <div style={{ color: "var(--text-secondary)" }}>Try adjusting your filters or search terms.</div>
              </div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20, animation: "fadeInUp 0.3s ease" }}>
                {filtered.map((product) => (
                  <ProductCard key={product.id} product={product} onAddToPortfolio={addToPortfolio} isInPortfolio={isInPortfolio(product.id)} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
