import React from "react";
import { Link } from "react-router-dom";
import RecommendationList from "../components/RecommendationList";
import { useUserProfile } from "../contexts/UserProfileContext";
import { usePortfolio } from "../contexts/PortfolioContext";
import { getRecommendations } from "../utils/recommendations";

export default function Recommendations({ products }) {
  const { profile, hasProfile } = useUserProfile();
  const { addToPortfolio, isInPortfolio } = usePortfolio();

  const recommendations = hasProfile ? getRecommendations(products, profile) : [];

  const riskLabels = { conservative: "Conservative 🛡️", moderate: "Moderate ⚖️", aggressive: "Aggressive 🚀" };
  const goalLabels = { wealth_building: "Wealth Building", retirement: "Retirement Planning", emergency_fund: "Emergency Fund", specific_purchase: "Specific Purchase" };

  if (!hasProfile) {
    return (
      <div className="page-wrapper page-enter">
        <div className="container" style={{ padding: "80px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 60, marginBottom: 20 }}>🎯</div>
          <h2 style={{ fontWeight: 800, fontSize: 28, color: "var(--text-primary)", marginBottom: 12 }}>No Profile Yet</h2>
          <p style={{ color: "var(--text-secondary)", marginBottom: 28, maxWidth: 400, margin: "0 auto 28px" }}>
            Create your financial profile first. Our recommendation engine uses your risk tolerance, 
            investment horizon, and goals to suggest the best products for you.
          </p>
          <Link to="/profile" className="btn btn-primary" style={{ fontSize: 15, padding: "12px 28px" }}>Create My Profile →</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page-wrapper page-enter">
      <div className="container" style={{ padding: "40px 24px" }}>
        {/* Header */}
        <div style={{ marginBottom: 32 }}>
          <h1 className="section-title">Your Recommendations</h1>
          <p className="section-subtitle">{recommendations.length} products matched to your financial profile</p>
        </div>

        {/* Profile summary banner */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius-lg)", padding: "16px 24px", marginBottom: 28, display: "flex", gap: 20, flexWrap: "wrap", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
            {[
              { label: "Risk", value: riskLabels[profile.riskTolerance] },
              { label: "Horizon", value: profile.investmentHorizon },
              { label: "Budget", value: profile.monthlyCapacity ? `PKR ${parseInt(profile.monthlyCapacity).toLocaleString()}` : "—" },
              { label: "Goal", value: goalLabels[profile.investmentGoal] },
            ].map(({ label, value }) => (
              <div key={label}>
                <div style={{ fontSize: 10, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</div>
                <div style={{ fontWeight: 700, fontSize: 14, color: "var(--text-primary)", textTransform: "capitalize" }}>{value}</div>
              </div>
            ))}
          </div>
          <Link to="/profile" className="btn btn-outline" style={{ fontSize: 12, padding: "8px 16px" }}>Edit Profile</Link>
        </div>

        {/* Explanation of logic */}
        <div style={{ background: "var(--accent-dim)", border: "1px solid var(--border-strong)", borderRadius: "var(--radius)", padding: "12px 18px", marginBottom: 28, fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.7 }}>
          <strong style={{ color: "var(--accent)" }}>How we picked these:</strong> Products are filtered by your risk tolerance 
          ({profile.riskTolerance === "conservative" ? "low risk only" : profile.riskTolerance === "moderate" ? "low & medium risk" : "all risk levels"}), 
          investment horizon ({profile.investmentHorizon} term products), liquidity preference ({profile.liquidityPreference}), 
          and budget (min. investment ≤ PKR {parseInt(profile.monthlyCapacity || 0).toLocaleString()}). 
          Sorted by best fit for your goal.
        </div>

        <RecommendationList
          recommendations={recommendations}
          profile={profile}
          onAddToPortfolio={addToPortfolio}
          isInPortfolio={isInPortfolio}
        />
      </div>
    </div>
  );
}
