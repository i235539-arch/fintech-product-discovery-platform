import React, { useState } from "react";
import { Link } from "react-router-dom";
import RiskBadge from "./RiskBadge";
import ReturnDisplay from "./ReturnDisplay";
import { formatCurrency } from "../utils/transformData";

/**
 * ProductCard - displays a financial product summary card
 * Props: product, onAddToPortfolio, isInPortfolio
 */
export default function ProductCard({ product, onAddToPortfolio, isInPortfolio }) {
  const [adding, setAdding] = useState(false);
  const [hovered, setHovered] = useState(false);

  async function handleAdd() {
    if (isInPortfolio) return;
    setAdding(true);
    onAddToPortfolio(product);
    setTimeout(() => setAdding(false), 1500);
  }

  const categoryColors = {
    savings: "var(--accent)",
    investment: "var(--gold)",
    insurance: "#ce93d8",
    crypto: "#ff8a80",
  };
  const catColor = categoryColors[product.category] || "var(--accent)";

  const liquidityLabels = { easy: "💧 Easy", moderate: "🔸 Moderate", locked: "🔒 Locked" };
  const horizonLabels = { short: "< 2yr", medium: "3-5yr", long: "5+yr" };

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: hovered ? "var(--bg-card-hover)" : "var(--bg-card)",
        border: hovered ? "1px solid var(--border-strong)" : "1px solid var(--border)",
        borderRadius: "var(--radius-lg)",
        overflow: "hidden",
        transition: "all 0.3s ease",
        transform: hovered ? "translateY(-4px)" : "translateY(0)",
        boxShadow: hovered
          ? "0 8px 32px rgba(0,0,0,0.5), 0 0 20px rgba(0,212,255,0.1)"
          : "0 2px 12px rgba(0,0,0,0.3)",
        display: "flex",
        flexDirection: "column",
        position: "relative",
      }}
    >
      {/* Top accent bar */}
      <div
        style={{
          height: 3,
          background: `linear-gradient(90deg, ${catColor}, transparent)`,
        }}
      />

      {/* Image area */}
      <div
        style={{
          height: 140,
          background: "var(--surface)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <img
          src={product.image}
          alt={product.name}
          style={{
            height: "80%",
            objectFit: "contain",
            filter: "brightness(0.85)",
            transition: "all 0.3s ease",
            transform: hovered ? "scale(1.05)" : "scale(1)",
          }}
        />
        {/* Category badge overlay */}
        <div style={{ position: "absolute", top: 10, left: 10 }}>
          <span
            style={{
              background: "rgba(5,10,14,0.85)",
              border: `1px solid ${catColor}40`,
              color: catColor,
              fontSize: 10,
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.5px",
              padding: "3px 8px",
              borderRadius: 6,
            }}
          >
            {product.category}
          </span>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: "16px", flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
        {/* Name */}
        <h3
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: "var(--text-primary)",
            lineHeight: 1.4,
            display: "-webkit-box",
            WebkitLineClamp: 2,
            WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}
        >
          {product.name}
        </h3>

        {/* Return + Risk Row */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 10, color: "var(--text-muted)", marginBottom: 2, textTransform: "uppercase", letterSpacing: "0.5px" }}>
              Expected Return
            </div>
            <ReturnDisplay value={product.expectedReturn} showTrend size="md" />
          </div>
          <RiskBadge riskLevel={product.riskLevel} size="sm" />
        </div>

        {/* Hidden details on hover */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 8,
            maxHeight: hovered ? "100px" : "0px",
            opacity: hovered ? 1 : 0,
            overflow: "hidden",
            transition: "all 0.3s ease",
          }}
        >
          <div style={{ background: "var(--surface)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--text-muted)", marginBottom: 2 }}>Liquidity</div>
            <div style={{ fontSize: 12, color: "var(--text-primary)", fontWeight: 600 }}>
              {liquidityLabels[product.liquidity]}
            </div>
          </div>
          <div style={{ background: "var(--surface)", borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ fontSize: 10, color: "var(--text-muted)", marginBottom: 2 }}>Horizon</div>
            <div style={{ fontSize: 12, color: "var(--text-primary)", fontWeight: 600 }}>
              {horizonLabels[product.timeHorizon]}
            </div>
          </div>
        </div>

        {/* Min investment */}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Min. Investment:</span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--gold)", fontWeight: 700 }}>
            {formatCurrency(product.minInvestment)}
          </span>
        </div>

        {/* Actions */}
        <div style={{ display: "flex", gap: 8, marginTop: "auto" }}>
          <Link
            to={`/product/${product.id}`}
            className="btn btn-outline"
            style={{ flex: 1, justifyContent: "center", fontSize: 12, padding: "8px 12px" }}
          >
            View Details
          </Link>
          <button
            onClick={handleAdd}
            disabled={isInPortfolio}
            className={`btn ${isInPortfolio ? "btn-success" : "btn-primary"}`}
            style={{ flex: 1, justifyContent: "center", fontSize: 12, padding: "8px 12px" }}
          >
            {isInPortfolio ? "✓ Added" : adding ? "Adding..." : "+ Portfolio"}
          </button>
        </div>
      </div>
    </div>
  );
}
