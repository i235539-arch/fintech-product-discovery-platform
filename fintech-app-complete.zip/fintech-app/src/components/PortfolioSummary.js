import React from "react";
import { formatCurrency } from "../utils/transformData";

/**
 * PortfolioSummary - displays portfolio statistics overview
 * Props: portfolio (from context — pass all values)
 */
export default function PortfolioSummary({
  totalInvested,
  weightedReturn,
  riskDistribution,
  diversificationScore,
  highRiskWarning,
  portfolio,
}) {
  const riskBarConfig = [
    { key: "low", label: "Low Risk", color: "#00e676" },
    { key: "medium", label: "Medium Risk", color: "#ffc107" },
    { key: "high", label: "High Risk", color: "#ff5252" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Warning */}
      {highRiskWarning && (
        <div
          style={{
            background: "rgba(255,82,82,0.1)",
            border: "1px solid rgba(255,82,82,0.4)",
            borderRadius: "var(--radius)",
            padding: "12px 16px",
            display: "flex",
            gap: 10,
            alignItems: "center",
          }}
        >
          <span style={{ fontSize: 18 }}>⚠️</span>
          <div>
            <div style={{ color: "#ff5252", fontWeight: 700, fontSize: 13 }}>High Risk Concentration</div>
            <div style={{ color: "var(--text-secondary)", fontSize: 12 }}>
              Over 60% of your portfolio is in high-risk products. Consider diversifying.
            </div>
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
        <div className="stat-box">
          <div className="stat-value" style={{ fontSize: 20 }}>{formatCurrency(totalInvested)}</div>
          <div className="stat-label">Total Invested</div>
        </div>
        <div className="stat-box">
          <div className="stat-value" style={{ fontSize: 20, color: "#ffc107" }}>
            {weightedReturn.toFixed(2)}%
          </div>
          <div className="stat-label">Weighted Return</div>
        </div>
        <div className="stat-box">
          <div className="stat-value" style={{ fontSize: 20, color: "#ce93d8" }}>{portfolio.length}</div>
          <div className="stat-label">Products</div>
        </div>
        <div className="stat-box">
          <div
            className="stat-value"
            style={{
              fontSize: 20,
              color:
                diversificationScore > 70 ? "#00e676" : diversificationScore > 40 ? "#ffc107" : "#ff5252",
            }}
          >
            {diversificationScore}/100
          </div>
          <div className="stat-label">Diversification</div>
        </div>
      </div>

      {/* Risk Distribution */}
      <div
        style={{
          background: "var(--bg-card)",
          border: "1px solid var(--border)",
          borderRadius: "var(--radius)",
          padding: 16,
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>
          Risk Distribution
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {riskBarConfig.map(({ key, label, color }) => (
            <div key={key}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>{label}</span>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: 12, color, fontWeight: 700 }}>
                  {(riskDistribution[key] || 0).toFixed(1)}%
                </span>
              </div>
              <div className="progress-bar-wrap">
                <div
                  className="progress-bar-fill"
                  style={{
                    width: `${riskDistribution[key] || 0}%`,
                    background: color,
                    opacity: 0.8,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Projected Annual Return */}
      {totalInvested > 0 && (
        <div
          style={{
            background: "var(--accent-dim)",
            border: "1px solid var(--border-strong)",
            borderRadius: "var(--radius)",
            padding: 16,
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", marginBottom: 8 }}>
            Projected Annual Gain
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 24, color: "var(--accent)", fontWeight: 700 }}>
            {formatCurrency(Math.round((totalInvested * weightedReturn) / 100))}
          </div>
          <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 4 }}>
            Based on weighted avg. return of {weightedReturn.toFixed(2)}%
          </div>
        </div>
      )}
    </div>
  );
}
