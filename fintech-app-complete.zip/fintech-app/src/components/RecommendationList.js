import React from "react";
import ProductCard from "./ProductCard";
import { getMatchScore } from "../utils/recommendations";

/**
 * RecommendationList - shows recommended products based on profile
 * Props: recommendations, profile, onAddToPortfolio, isInPortfolio
 */
export default function RecommendationList({ recommendations, profile, onAddToPortfolio, isInPortfolio }) {
  if (!recommendations || recommendations.length === 0) {
    return (
      <div
        style={{
          textAlign: "center",
          padding: "60px 24px",
          background: "var(--bg-card)",
          border: "1px solid var(--border)",
          borderRadius: "var(--radius-lg)",
        }}
      >
        <div style={{ fontSize: 40, marginBottom: 16 }}>🔍</div>
        <div style={{ fontWeight: 700, fontSize: 18, color: "var(--text-primary)", marginBottom: 8 }}>
          No Matching Products
        </div>
        <div style={{ color: "var(--text-secondary)", maxWidth: 360, margin: "0 auto" }}>
          Try adjusting your investment capacity or changing your risk tolerance in your profile.
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: 20,
        }}
      >
        {recommendations.map((product, index) => {
          const score = getMatchScore(product, profile);
          return (
            <div key={product.id} style={{ position: "relative" }}>
              {/* Match score badge */}
              <div
                style={{
                  position: "absolute",
                  top: -10,
                  right: 12,
                  zIndex: 10,
                  background: score >= 80 ? "var(--risk-low)" : score >= 60 ? "var(--risk-medium)" : "var(--surface)",
                  color: score >= 80 ? "var(--bg-primary)" : score >= 60 ? "var(--bg-primary)" : "var(--text-secondary)",
                  fontSize: 10,
                  fontWeight: 800,
                  padding: "3px 8px",
                  borderRadius: 10,
                  fontFamily: "var(--font-mono)",
                }}
              >
                {score}% match
              </div>
              {index === 0 && (
                <div
                  style={{
                    position: "absolute",
                    top: -10,
                    left: 12,
                    zIndex: 10,
                    background: "var(--gold)",
                    color: "var(--bg-primary)",
                    fontSize: 9,
                    fontWeight: 800,
                    padding: "3px 8px",
                    borderRadius: 10,
                    textTransform: "uppercase",
                    letterSpacing: "0.5px",
                  }}
                >
                  ⭐ Top Pick
                </div>
              )}
              <ProductCard
                product={product}
                onAddToPortfolio={onAddToPortfolio}
                isInPortfolio={isInPortfolio(product.id)}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
