import React from "react";

/**
 * RiskBadge - displays risk level with color coding
 * Props: riskLevel (low|medium|high), size (sm|md|lg)
 */
export default function RiskBadge({ riskLevel, size = "md" }) {
  const config = {
    low: { label: "Low Risk", color: "#00e676", bg: "rgba(0,230,118,0.12)", border: "rgba(0,230,118,0.3)", icon: "▼" },
    medium: { label: "Med Risk", color: "#ffc107", bg: "rgba(255,193,7,0.12)", border: "rgba(255,193,7,0.3)", icon: "◆" },
    high: { label: "High Risk", color: "#ff5252", bg: "rgba(255,82,82,0.12)", border: "rgba(255,82,82,0.3)", icon: "▲" },
  };

  const sizes = {
    sm: { fontSize: 10, padding: "2px 8px" },
    md: { fontSize: 11, padding: "4px 10px" },
    lg: { fontSize: 13, padding: "6px 14px" },
  };

  const cfg = config[riskLevel] || config.medium;
  const sz = sizes[size] || sizes.md;

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        background: cfg.bg,
        color: cfg.color,
        border: `1px solid ${cfg.border}`,
        borderRadius: 20,
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: "0.5px",
        ...sz,
      }}
    >
      <span style={{ fontSize: sz.fontSize - 2 }}>{cfg.icon}</span>
      {cfg.label}
    </span>
  );
}
