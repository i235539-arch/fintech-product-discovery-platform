import React from "react";

/**
 * ReturnDisplay - formats expected return percentage
 * Props: value (number), showTrend (bool), size (sm|md|lg)
 */
export default function ReturnDisplay({ value, showTrend = false, size = "md" }) {
  const sizes = {
    sm: { fontSize: 14 },
    md: { fontSize: 20 },
    lg: { fontSize: 32 },
  };

  const color = value >= 15 ? "#ff8a80" : value >= 8 ? "#ffc107" : "#00e676";
  const trend = value >= 10 ? "↑" : "→";

  return (
    <span
      style={{
        fontFamily: "var(--font-mono)",
        fontWeight: 700,
        color,
        fontSize: sizes[size]?.fontSize || 20,
        display: "inline-flex",
        alignItems: "baseline",
        gap: 2,
      }}
    >
      {showTrend && <span style={{ fontSize: "0.75em" }}>{trend}</span>}
      {value?.toFixed(1)}
      <span style={{ fontSize: "0.65em", opacity: 0.8 }}>%</span>
    </span>
  );
}
