import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { usePortfolio } from "../contexts/PortfolioContext";
import { useUserProfile } from "../contexts/UserProfileContext";

export default function Navbar() {
  const location = useLocation();
  const { portfolio } = usePortfolio();
  const { hasProfile } = useUserProfile();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [location]);

  const navLinks = [
    { to: "/", label: "Home" },
    { to: "/products", label: "Products" },
    { to: "/profile", label: "Profile" },
    { to: "/recommendations", label: "Recommendations" },
    { to: "/portfolio", label: "Portfolio" },
  ];

  const isActive = (path) =>
    path === "/" ? location.pathname === "/" : location.pathname.startsWith(path);

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1000,
        height: "var(--nav-height)",
        background: scrolled
          ? "rgba(5, 10, 14, 0.95)"
          : "rgba(5, 10, 14, 0.7)",
        backdropFilter: "blur(20px)",
        borderBottom: scrolled ? "1px solid var(--border)" : "1px solid transparent",
        transition: "all 0.3s ease",
      }}
    >
      <div
        className="container"
        style={{
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        {/* Logo */}
        <Link to="/" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 36,
              height: 36,
              background: "var(--accent)",
              borderRadius: 8,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 18,
              fontWeight: 800,
              color: "var(--bg-primary)",
              fontFamily: "var(--font-mono)",
            }}
          >
            F
          </div>
          <span
            style={{
              fontWeight: 800,
              fontSize: 20,
              color: "var(--text-primary)",
              letterSpacing: "-0.5px",
            }}
          >
            Fin<span style={{ color: "var(--accent)" }}>Vest</span>
          </span>
        </Link>

        {/* Desktop Nav Links */}
        <div style={{ display: "flex", gap: 4, alignItems: "center" }} className="desktop-nav">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              style={{
                padding: "8px 16px",
                borderRadius: 8,
                textDecoration: "none",
                fontSize: 14,
                fontWeight: 500,
                transition: "all 0.2s ease",
                background: isActive(link.to) ? "var(--accent-dim)" : "transparent",
                color: isActive(link.to) ? "var(--accent)" : "var(--text-secondary)",
                border: isActive(link.to) ? "1px solid var(--border-strong)" : "1px solid transparent",
                position: "relative",
              }}
            >
              {link.label}
              {link.to === "/portfolio" && portfolio.length > 0 && (
                <span
                  style={{
                    position: "absolute",
                    top: 2,
                    right: 2,
                    width: 18,
                    height: 18,
                    background: "var(--accent)",
                    borderRadius: "50%",
                    fontSize: 10,
                    fontWeight: 700,
                    color: "var(--bg-primary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {portfolio.length}
                </span>
              )}
              {link.to === "/recommendations" && !hasProfile && (
                <span
                  style={{
                    position: "absolute",
                    top: 2,
                    right: 2,
                    width: 8,
                    height: 8,
                    background: "var(--gold)",
                    borderRadius: "50%",
                  }}
                />
              )}
            </Link>
          ))}
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          style={{
            display: "none",
            background: "none",
            border: "none",
            color: "var(--text-primary)",
            cursor: "pointer",
            padding: 8,
            fontSize: 22,
          }}
          className="hamburger"
        >
          {menuOpen ? "✕" : "☰"}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          style={{
            background: "var(--bg-secondary)",
            borderTop: "1px solid var(--border)",
            padding: "12px 24px",
            display: "flex",
            flexDirection: "column",
            gap: 4,
          }}
        >
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              style={{
                padding: "12px 16px",
                borderRadius: 8,
                textDecoration: "none",
                fontSize: 15,
                fontWeight: 500,
                color: isActive(link.to) ? "var(--accent)" : "var(--text-primary)",
                background: isActive(link.to) ? "var(--accent-dim)" : "transparent",
              }}
            >
              {link.label}
              {link.to === "/portfolio" && portfolio.length > 0 && ` (${portfolio.length})`}
            </Link>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .hamburger { display: flex !important; }
        }
      `}</style>
    </nav>
  );
}
