import React, { useState } from "react";

/**
 * ProfileForm - user financial profile input
 * Props: profile, onSubmit, onChange
 */
export default function ProfileForm({ profile, onSubmit, onChange }) {
  const [errors, setErrors] = useState({});

  function validate(data) {
    const e = {};
    if (!data.riskTolerance) e.riskTolerance = "Please select your risk tolerance";
    if (!data.investmentHorizon) e.investmentHorizon = "Please select your investment horizon";
    if (!data.monthlyCapacity || parseFloat(data.monthlyCapacity) < 1000)
      e.monthlyCapacity = "Minimum investment capacity is PKR 1,000";
    if (!data.liquidityPreference) e.liquidityPreference = "Please select a liquidity preference";
    if (!data.investmentGoal) e.investmentGoal = "Please select your investment goal";
    return e;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errs = validate(profile);
    setErrors(errs);
    if (Object.keys(errs).length === 0) {
      onSubmit(profile);
    }
  }

  const RadioGroup = ({ label, field, options, description }) => (
    <div className="form-group" style={{ marginBottom: 24 }}>
      <label className="form-label">{label}</label>
      {description && (
        <p style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 8 }}>{description}</p>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {options.map(({ value, label: optLabel, sub }) => {
          const selected = profile[field] === value;
          return (
            <label
              key={value}
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: 12,
                cursor: "pointer",
                padding: "12px 16px",
                borderRadius: "var(--radius)",
                background: selected ? "var(--accent-dim)" : "var(--surface)",
                border: selected ? "1px solid var(--border-strong)" : "1px solid var(--border)",
                transition: "all 0.2s ease",
              }}
            >
              <input
                type="radio"
                name={field}
                value={value}
                checked={selected}
                onChange={() => onChange({ ...profile, [field]: value })}
                style={{ display: "none" }}
              />
              <div
                style={{
                  width: 18,
                  height: 18,
                  borderRadius: "50%",
                  border: `2px solid ${selected ? "var(--accent)" : "var(--border-strong)"}`,
                  background: selected ? "var(--accent)" : "transparent",
                  flexShrink: 0,
                  marginTop: 2,
                  transition: "all 0.2s ease",
                }}
              />
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, color: "var(--text-primary)" }}>{optLabel}</div>
                {sub && <div style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 2 }}>{sub}</div>}
              </div>
            </label>
          );
        })}
      </div>
      {errors[field] && <span className="form-error">{errors[field]}</span>}
    </div>
  );

  return (
    <form onSubmit={handleSubmit}>
      <RadioGroup
        label="Risk Tolerance"
        field="riskTolerance"
        description="How comfortable are you with potential losses in exchange for higher returns?"
        options={[
          { value: "conservative", label: "Conservative", sub: "I prefer safe investments. Minimal risk, even if returns are lower." },
          { value: "moderate", label: "Moderate", sub: "I can accept some risk for better returns. Balanced approach." },
          { value: "aggressive", label: "Aggressive", sub: "I'm comfortable with high risk for potentially high returns." },
        ]}
      />

      <RadioGroup
        label="Investment Horizon"
        field="investmentHorizon"
        description="How long do you plan to keep your money invested?"
        options={[
          { value: "short", label: "Short Term", sub: "1–2 years. I may need my money soon." },
          { value: "medium", label: "Medium Term", sub: "3–5 years. Planning ahead but not too far." },
          { value: "long", label: "Long Term", sub: "5+ years. Building wealth for the future." },
        ]}
      />

      <div className="form-group" style={{ marginBottom: 24 }}>
        <label className="form-label">Monthly Investment Capacity (PKR)</label>
        <p style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 8 }}>
          How much can you invest per month? This filters products to ones you can afford.
        </p>
        <input
          type="number"
          value={profile.monthlyCapacity || ""}
          onChange={(e) => onChange({ ...profile, monthlyCapacity: e.target.value })}
          className="form-input"
          placeholder="e.g. 25000"
          min={1000}
        />
        {errors.monthlyCapacity && <span className="form-error">{errors.monthlyCapacity}</span>}
      </div>

      <RadioGroup
        label="Liquidity Preference"
        field="liquidityPreference"
        description="How quickly do you need access to your money if needed?"
        options={[
          { value: "easy", label: "Easy Access", sub: "I need to be able to withdraw anytime." },
          { value: "moderate", label: "Some Flexibility", sub: "I can wait a few months if needed." },
          { value: "locked", label: "Can Lock Funds", sub: "I'm fine locking funds for years for better returns." },
        ]}
      />

      <RadioGroup
        label="Investment Goal"
        field="investmentGoal"
        description="What is the primary purpose of your investment?"
        options={[
          { value: "wealth_building", label: "Wealth Building", sub: "Growing my assets over time." },
          { value: "retirement", label: "Retirement Planning", sub: "Securing my financial future." },
          { value: "emergency_fund", label: "Emergency Fund", sub: "Building a financial safety net." },
          { value: "specific_purchase", label: "Specific Purchase", sub: "Saving for a car, house, or other goal." },
        ]}
      />

      <button type="submit" className="btn btn-primary" style={{ width: "100%", justifyContent: "center", padding: "14px 24px", fontSize: 15 }}>
        Save Profile & Get Recommendations →
      </button>
    </form>
  );
}
