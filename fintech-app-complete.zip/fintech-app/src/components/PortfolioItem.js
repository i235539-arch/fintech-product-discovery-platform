import React, { useState } from "react";
import { formatCurrency } from "../utils/transformData";
import RiskBadge from "./RiskBadge";
import ReturnDisplay from "./ReturnDisplay";

/**
 * PortfolioItem - single portfolio entry
 * Props: item, onRemove, onUpdateAmount
 */
export default function PortfolioItem({ item, onRemove, onUpdateAmount }) {
  const [editing, setEditing] = useState(false);
  const [tempAmount, setTempAmount] = useState(item.allocatedAmount);

  function handleSave() {
    const parsed = parseFloat(tempAmount);
    if (!isNaN(parsed) && parsed >= item.minInvestment) {
      onUpdateAmount(item.id, parsed);
      setEditing(false);
    }
  }

  const projectedGain = (item.allocatedAmount * item.expectedReturn) / 100;

  return (
    <div
      style={{
        background: "var(--bg-card)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius)",
        padding: "16px 20px",
        display: "flex",
        alignItems: "center",
        gap: 16,
        transition: "all 0.2s ease",
      }}
    >
      {/* Image */}
      <div
        style={{
          width: 50,
          height: 50,
          background: "var(--surface)",
          borderRadius: 10,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          overflow: "hidden",
        }}
      >
        <img
          src={item.image}
          alt={item.name}
          style={{ width: "80%", height: "80%", objectFit: "contain", filter: "brightness(0.85)" }}
        />
      </div>

      {/* Name & badges */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontWeight: 700,
            fontSize: 14,
            color: "var(--text-primary)",
            marginBottom: 4,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {item.name}
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <RiskBadge riskLevel={item.riskLevel} size="sm" />
          <span
            style={{
              fontSize: 11,
              color: "var(--text-muted)",
              background: "var(--surface)",
              padding: "2px 8px",
              borderRadius: 10,
            }}
          >
            {item.category}
          </span>
        </div>
      </div>

      {/* Return */}
      <div style={{ textAlign: "center", flexShrink: 0 }}>
        <ReturnDisplay value={item.expectedReturn} size="sm" />
        <div style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 2 }}>return/yr</div>
      </div>

      {/* Amount */}
      <div style={{ flexShrink: 0, minWidth: 120 }}>
        {editing ? (
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input
              type="number"
              value={tempAmount}
              onChange={(e) => setTempAmount(e.target.value)}
              className="form-input"
              style={{ padding: "6px 10px", fontSize: 13, width: 110 }}
              min={item.minInvestment}
            />
            <button
              onClick={handleSave}
              className="btn btn-primary"
              style={{ padding: "6px 10px", fontSize: 11, flexShrink: 0 }}
            >
              ✓
            </button>
            <button
              onClick={() => { setTempAmount(item.allocatedAmount); setEditing(false); }}
              className="btn btn-ghost"
              style={{ padding: "6px 10px", fontSize: 11, flexShrink: 0 }}
            >
              ✕
            </button>
          </div>
        ) : (
          <div>
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontWeight: 700,
                fontSize: 14,
                color: "var(--gold)",
                cursor: "pointer",
              }}
              onClick={() => setEditing(true)}
              title="Click to edit"
            >
              {formatCurrency(item.allocatedAmount)} ✎
            </div>
            <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>
              +{formatCurrency(Math.round(projectedGain))}/yr
            </div>
          </div>
        )}
      </div>

      {/* Remove */}
      <button
        onClick={() => onRemove(item.id)}
        className="btn btn-danger"
        style={{ padding: "8px 12px", fontSize: 11, flexShrink: 0 }}
      >
        Remove
      </button>
    </div>
  );
}
