import React from "react";

/**
 * FilterPanel - all filtering controls for product listing
 * Props: filters, onFilterChange, productCount
 */
export default function FilterPanel({ filters, onFilterChange, productCount }) {
  function toggle(field, value) {
    const current = filters[field] || [];
    const next = current.includes(value)
      ? current.filter((v) => v !== value)
      : [...current, value];
    onFilterChange({ ...filters, [field]: next });
  }

  function resetFilters() {
    onFilterChange({
      riskLevels: [],
      categories: [],
      liquidity: [],
      timeHorizon: [],
      minReturn: 0,
      maxReturn: 30,
      maxMinInvestment: "",
    });
  }

  const hasActiveFilters =
    filters.riskLevels?.length > 0 ||
    filters.categories?.length > 0 ||
    filters.liquidity?.length > 0 ||
    filters.timeHorizon?.length > 0 ||
    filters.minReturn > 0 ||
    filters.maxReturn < 30 ||
    filters.maxMinInvestment;

  const CheckGroup = ({ label, field, options }) => (
    <div style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 10 }}>
        {label}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {options.map(({ value, label: optLabel, color }) => {
          const active = (filters[field] || []).includes(value);
          return (
            <label
              key={value}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                cursor: "pointer",
                padding: "6px 10px",
                borderRadius: 8,
                background: active ? "var(--accent-dim)" : "transparent",
                border: active ? "1px solid var(--border-strong)" : "1px solid transparent",
                transition: "all 0.2s ease",
              }}
            >
              <input
                type="checkbox"
                checked={active}
                onChange={() => toggle(field, value)}
                style={{ display: "none" }}
              />
              <div
                style={{
                  width: 16,
                  height: 16,
                  borderRadius: 4,
                  border: `2px solid ${active ? (color || "var(--accent)") : "var(--border-strong)"}`,
                  background: active ? (color || "var(--accent)") : "transparent",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  transition: "all 0.2s ease",
                  flexShrink: 0,
                }}
              >
                {active && <span style={{ fontSize: 9, color: "var(--bg-primary)", fontWeight: 900 }}>✓</span>}
              </div>
              <span style={{ fontSize: 13, color: active ? "var(--text-primary)" : "var(--text-secondary)", fontWeight: active ? 600 : 400 }}>
                {optLabel}
              </span>
            </label>
          );
        })}
      </div>
    </div>
  );

  return (
    <div
      style={{
        background: "var(--bg-card)",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius-lg)",
        padding: 20,
        position: "sticky",
        top: "calc(var(--nav-height) + 20px)",
      }}
    >
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15, color: "var(--text-primary)" }}>Filters</div>
          <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>
            {productCount} product{productCount !== 1 ? "s" : ""} shown
          </div>
        </div>
        {hasActiveFilters && (
          <button
            onClick={resetFilters}
            style={{
              background: "none",
              border: "1px solid var(--border)",
              borderRadius: 6,
              color: "var(--text-muted)",
              fontSize: 11,
              cursor: "pointer",
              padding: "4px 8px",
              fontFamily: "var(--font-main)",
            }}
          >
            Reset
          </button>
        )}
      </div>

      <div style={{ height: 1, background: "var(--border)", marginBottom: 20 }} />

      {/* Risk Level */}
      <CheckGroup
        label="Risk Level"
        field="riskLevels"
        options={[
          { value: "low", label: "Low Risk", color: "#00e676" },
          { value: "medium", label: "Medium Risk", color: "#ffc107" },
          { value: "high", label: "High Risk", color: "#ff5252" },
        ]}
      />

      {/* Category */}
      <CheckGroup
        label="Category"
        field="categories"
        options={[
          { value: "savings", label: "Savings", color: "var(--accent)" },
          { value: "investment", label: "Investment", color: "var(--gold)" },
          { value: "insurance", label: "Insurance", color: "#ce93d8" },
          { value: "crypto", label: "Crypto", color: "#ff8a80" },
        ]}
      />

      {/* Liquidity */}
      <CheckGroup
        label="Liquidity"
        field="liquidity"
        options={[
          { value: "easy", label: "Easy Access" },
          { value: "moderate", label: "Moderate" },
          { value: "locked", label: "Locked-In" },
        ]}
      />

      {/* Time Horizon */}
      <CheckGroup
        label="Time Horizon"
        field="timeHorizon"
        options={[
          { value: "short", label: "Short (< 2 years)" },
          { value: "medium", label: "Medium (3–5 years)" },
          { value: "long", label: "Long (5+ years)" },
        ]}
      />

      {/* Return Range */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 10 }}>
          Return Range
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input
            type="number"
            value={filters.minReturn || 0}
            min={0}
            max={30}
            onChange={(e) => onFilterChange({ ...filters, minReturn: parseFloat(e.target.value) || 0 })}
            className="form-input"
            style={{ padding: "8px 10px", fontSize: 13, width: "70px" }}
            placeholder="0"
          />
          <span style={{ color: "var(--text-muted)", fontSize: 13 }}>%  to</span>
          <input
            type="number"
            value={filters.maxReturn || 30}
            min={0}
            max={50}
            onChange={(e) => onFilterChange({ ...filters, maxReturn: parseFloat(e.target.value) || 30 })}
            className="form-input"
            style={{ padding: "8px 10px", fontSize: 13, width: "70px" }}
            placeholder="30"
          />
          <span style={{ color: "var(--text-muted)", fontSize: 13 }}>%</span>
        </div>
      </div>

      {/* Max Min Investment */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 10 }}>
          My Budget (PKR)
        </div>
        <input
          type="number"
          value={filters.maxMinInvestment || ""}
          onChange={(e) => onFilterChange({ ...filters, maxMinInvestment: e.target.value })}
          className="form-input"
          style={{ padding: "8px 10px", fontSize: 13 }}
          placeholder="e.g. 50000"
        />
        <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 6 }}>
          Shows products you can afford
        </div>
      </div>
    </div>
  );
}
