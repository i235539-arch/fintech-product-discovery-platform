import React, { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { PortfolioProvider } from "./contexts/PortfolioContext";
import { UserProfileProvider } from "./contexts/UserProfileContext";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import ProductListing from "./pages/ProductListing";
import ProductDetail from "./pages/ProductDetail";
import UserProfile from "./pages/UserProfile";
import Portfolio from "./pages/Portfolio";
import Recommendations from "./pages/Recommendations";
import NotFound from "./pages/NotFound";
import { fetchFinancialProducts } from "./utils/transformData";

function AppContent() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchFinancialProducts()
      .then((data) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("API fetch failed:", err);
        setError("Failed to load products. Please refresh.");
        setLoading(false);
      });
  }, []);

  return (
    <>
      <Navbar />
      {error && (
        <div style={{ background: "var(--risk-high-dim)", border: "1px solid rgba(255,82,82,0.4)", padding: "10px 24px", textAlign: "center", fontSize: 13, color: "var(--risk-high)", marginTop: "var(--nav-height)" }}>
          ⚠️ {error}
        </div>
      )}
      <Routes>
        <Route path="/" element={<Home products={products} loading={loading} />} />
        <Route path="/products" element={<ProductListing products={products} loading={loading} />} />
        <Route path="/product/:id" element={<ProductDetail products={products} />} />
        <Route path="/profile" element={<UserProfile products={products} />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/recommendations" element={<Recommendations products={products} />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <PortfolioProvider>
        <UserProfileProvider>
          <AppContent />
        </UserProfileProvider>
      </PortfolioProvider>
    </BrowserRouter>
  );
}
