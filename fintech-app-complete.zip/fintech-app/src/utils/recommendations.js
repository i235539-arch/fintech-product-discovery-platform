// ============================================
// RECOMMENDATION ENGINE
// Maps user profile to suitable products
// ============================================

/**
 * Risk tolerance → allowed product risk levels
 */
const riskTolerance = {
  conservative: ["low"],
  moderate: ["low", "medium"],
  aggressive: ["low", "medium", "high"],
};

/**
 * Investment horizon → allowed product time horizons
 */
const horizonMap = {
  short: ["short"],
  medium: ["short", "medium"],
  long: ["short", "medium", "long"],
};

/**
 * Liquidity preference → allowed product liquidity levels
 */
const liquidityMap = {
  easy: ["easy"],
  moderate: ["easy", "moderate"],
  locked: ["easy", "moderate", "locked"],
};

/**
 * Goal → preferred categories
 */
const goalCategoryPreference = {
  wealth_building: ["investment", "crypto"],
  retirement: ["savings", "investment", "insurance"],
  emergency_fund: ["savings"],
  specific_purchase: ["savings", "investment"],
};

/**
 * Core recommendation function.
 * Takes products array and user profile, returns sorted recommended products.
 */
export function getRecommendations(products, userProfile) {
  if (!userProfile || !userProfile.riskTolerance) return [];

  const allowedRisk = riskTolerance[userProfile.riskTolerance] || ["low"];
  const allowedHorizon = horizonMap[userProfile.investmentHorizon] || ["short"];
  const allowedLiquidity = liquidityMap[userProfile.liquidityPreference] || ["easy"];
  const budget = parseFloat(userProfile.monthlyCapacity) || 0;
  const preferredCategories = userProfile.investmentGoal
    ? goalCategoryPreference[userProfile.investmentGoal] || []
    : [];

  // Filter products by all criteria
  const filtered = products.filter((p) => {
    const riskOk = allowedRisk.includes(p.riskLevel);
    const horizonOk = allowedHorizon.includes(p.timeHorizon);
    const liquidityOk = allowedLiquidity.includes(p.liquidity);
    const budgetOk = budget === 0 || p.minInvestment <= budget;
    return riskOk && horizonOk && liquidityOk && budgetOk;
  });

  // Sort: for conservative → lowest risk first, then by return desc
  // For aggressive → highest return first
  // For moderate → balance of risk and return
  const sorted = [...filtered].sort((a, b) => {
    if (userProfile.riskTolerance === "conservative") {
      const riskOrder = { low: 0, medium: 1, high: 2 };
      if (riskOrder[a.riskLevel] !== riskOrder[b.riskLevel])
        return riskOrder[a.riskLevel] - riskOrder[b.riskLevel];
      return b.expectedReturn - a.expectedReturn;
    }
    if (userProfile.riskTolerance === "aggressive") {
      return b.expectedReturn - a.expectedReturn;
    }
    // Moderate: sort by goal-preferred categories first, then return
    const aPref = preferredCategories.includes(a.category) ? 0 : 1;
    const bPref = preferredCategories.includes(b.category) ? 0 : 1;
    if (aPref !== bPref) return aPref - bPref;
    return b.expectedReturn - a.expectedReturn;
  });

  return sorted;
}

/**
 * Returns a score (0-100) for how well a product matches user profile
 */
export function getMatchScore(product, userProfile) {
  if (!userProfile?.riskTolerance) return 0;
  let score = 0;

  const allowedRisk = riskTolerance[userProfile.riskTolerance] || [];
  const allowedHorizon = horizonMap[userProfile.investmentHorizon] || [];
  const allowedLiquidity = liquidityMap[userProfile.liquidityPreference] || [];

  if (allowedRisk.includes(product.riskLevel)) score += 35;
  if (allowedHorizon.includes(product.timeHorizon)) score += 30;
  if (allowedLiquidity.includes(product.liquidity)) score += 20;

  const budget = parseFloat(userProfile.monthlyCapacity) || 0;
  if (budget === 0 || product.minInvestment <= budget) score += 15;

  return score;
}
