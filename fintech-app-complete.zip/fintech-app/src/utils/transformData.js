// ============================================
// DATA TRANSFORMATION UTILITIES
// Transforms raw API data into financial products
// ============================================

/**
 * Maps API category strings to FinTech categories
 */
const categoryMapping = {
  "electronics": "investment",
  "jewelery": "savings",
  "men's clothing": "insurance",
  "women's clothing": "crypto",
};

/**
 * Maps financial category to risk level
 * Systematic assignment — not random
 */
const riskMapping = {
  investment: "medium",
  savings: "low",
  insurance: "low",
  crypto: "high",
};

/**
 * Maps risk level to liquidity
 * High risk (crypto) = easy liquidity (liquid markets)
 * Savings = easy (can withdraw)
 * Insurance = locked (long term)
 * Investment = moderate
 */
const liquidityMapping = {
  low: { savings: "easy", insurance: "locked" },
  medium: "moderate",
  high: "easy",
};

/**
 * Maps risk to time horizon
 */
const timeHorizonMapping = {
  low: "short",
  medium: "long",
  high: "medium",
};

/**
 * Assign expected return based on risk — deterministic per product (use id as seed)
 */
function assignReturn(riskLevel, id) {
  const seed = (id * 7919) % 100; // deterministic pseudo-random
  const ranges = {
    low: [3, 7],
    medium: [7, 12],
    high: [12, 27],
  };
  const [min, max] = ranges[riskLevel];
  return parseFloat((min + (seed / 100) * (max - min)).toFixed(2));
}

/**
 * Assign liquidity based on category and risk
 */
function assignLiquidity(category, riskLevel) {
  if (category === "savings") return "easy";
  if (category === "insurance") return "locked";
  if (category === "crypto") return "easy";
  if (category === "investment") return "moderate";
  return "moderate";
}

/**
 * Assign time horizon based on risk
 */
function assignTimeHorizon(riskLevel) {
  return timeHorizonMapping[riskLevel] || "medium";
}

/**
 * Transforms a single Fake Store API product into a FinTech financial product
 */
export function transformToFinancialProduct(apiProduct) {
  const category = categoryMapping[apiProduct.category] || "investment";
  const riskLevel = riskMapping[category];

  return {
    id: apiProduct.id,
    name: apiProduct.title.slice(0, 50), // cap length
    category,
    description: apiProduct.description,
    minInvestment: Math.round(apiProduct.price * 1000),
    riskLevel,
    expectedReturn: assignReturn(riskLevel, apiProduct.id),
    liquidity: assignLiquidity(category, riskLevel),
    timeHorizon: assignTimeHorizon(riskLevel),
    image: apiProduct.image,
    rating: apiProduct.rating?.rate || 4.0,
  };
}

/**
 * Transforms an array of API products
 */
export function transformAllProducts(apiProducts) {
  return apiProducts.map(transformToFinancialProduct);
}

/**
 * Fetches financial products from Fake Store API and transforms them
 */
export async function fetchFinancialProducts() {
  const response = await fetch("https://fakestoreapi.com/products");
  if (!response.ok) throw new Error("Failed to fetch products");
  const data = await response.json();
  return transformAllProducts(data);
}

/**
 * Returns color class for risk level
 */
export function riskColor(riskLevel) {
  const map = { low: "#00e676", medium: "#ffc107", high: "#ff5252" };
  return map[riskLevel] || "#7fa8c0";
}

/**
 * Format currency in PKR
 */
export function formatCurrency(amount) {
  if (amount >= 1000000) return `PKR ${(amount / 1000000).toFixed(1)}M`;
  if (amount >= 1000) return `PKR ${(amount / 1000).toFixed(0)}K`;
  return `PKR ${amount}`;
}

/**
 * Calculate projected return for a given amount and years
 * Using compound interest: A = P(1 + r/100)^t
 */
export function calcProjectedReturn(principal, annualReturnPct, years) {
  return principal * Math.pow(1 + annualReturnPct / 100, years);
}
